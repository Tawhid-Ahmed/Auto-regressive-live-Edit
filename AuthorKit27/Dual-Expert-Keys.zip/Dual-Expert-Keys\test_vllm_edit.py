#%%
from utils import get_full_model_name, load_vllm_editor
from evaluation.vllm_editor_eval import VLLMEditorEvaluation
from utils.GLOBAL import ROOT_PATH
from datetime import datetime
import os, argparse, time, json

def get_attr():
    parser = argparse.ArgumentParser()
    parser.add_argument('-en', '--editor_name', type=str, help='Editor name: LiveEdit, FT_VL...', required=True)
    parser.add_argument('-mn', '--edit_model_name', type=str, help='Editing model name: llava...', required=True)
    parser.add_argument('-sen', '--sequential_edit_n', type=int, help='Edit number.', required=True)
    parser.add_argument('-enp', '--eval_name_postfix', type=str, default = '', help='Optional tag in the run folder name (each run also gets a timestamp).')
    parser.add_argument('-dvc', '--device', type=str, help='CUDA device for editing.', required=True)
    parser.add_argument('-ckpt', '--editor_ckpt_path', type=str, default = None, help='For Editors that needs training.')
    parser.add_argument('-dn', '--data_name', type=str, required = True, help = 'Evaluating dataset, including EVQA, EIC.')
    parser.add_argument('-dsn', '--data_sample_n', type=int, default = None, help = 'Sample number for evaluation.')
    parser.add_argument('-seed', '--eval_seed', type=int, default=None, help = 'Fixed seed for eval data shuffle (enables reproducible split for comparison).')
    # AR-LiveEdit (no behavior change when ar_mode=False)
    parser.add_argument('--ar_mode', action='store_true', help='Enable autoregressive chunk-wise edit mode.')
    parser.add_argument('--chunk_size', type=int, default=16, help='Target chunk size in tokens for AR mode.')
    parser.add_argument('--max_chunks', type=int, default=None, help='Optional max chunks per target in AR mode (default: unlimited).')
    # Workstream E0: free-running (non-teacher-forced) reliability generation
    parser.add_argument('--free_running', action='store_true', help='Run free-running generation reliability eval (decode + EM) instead of teacher-forced scoring.')
    parser.add_argument('--gen_eval_n', type=int, default=200, help='Free-running only: number of reliability samples to generate (bounds runtime).')
    parser.add_argument('--gen_max_new_tokens', type=int, default=128, help='Free-running only: max new tokens to generate per sample.')
    parser.add_argument(
        '-dpath',
        '--vlkeb_eval_json',
        type=str,
        default=None,
        help='VLKEB only: path to eval JSON (default: data/VLKEB/eval.json under ROOT_PATH). Use for long-form `alt` smoke files.',
    )
    parser.add_argument(
        '--patch_grounding',
        action='store_true',
        help='Enable patch grounding module before ckpt load (AVBT / DEK).',
    )
    parser.add_argument(
        '--dek_dual_gate',
        action='store_true',
        help='Enable Dual-Expert Keys (DEK) before ckpt load.',
    )
    args = parser.parse_args()
    # Treat common sentinels as "no checkpoint"
    if isinstance(args.editor_ckpt_path, str) and args.editor_ckpt_path.strip().lower() in {"none", "null", ""}:
        args.editor_ckpt_path = None
    return args
 
class cfg:
    editor_name = 'liveedit'
    edit_model_name = 'blip2'
    sequential_edit_n = 100
    eval_name_postfix = 'test'
    device = 0
    editor_ckpt_path = 'records/...'
    data_name = 'EVQA' # 'EVQA', 'EIC'
    data_sample_n = 100 # 231, 530, 1300, 3000
    # AR-LiveEdit
    ar_mode = False
    chunk_size = 16
    max_chunks = None

if __name__ == '__main__':
    cfg = get_attr()
    cfg.editor_name = cfg.editor_name.lower()
    cfg.edit_model_name = get_full_model_name(cfg.edit_model_name)
    # Unique folder per run: DATA[-tag][-ar]-YYYY.MM.DD-HH.MM.SS (matches training record style)
    _parts = [cfg.data_name.upper()]
    if cfg.ar_mode:
        _parts.append('ar')
    if cfg.eval_name_postfix:
        _parts.append(cfg.eval_name_postfix)
    _parts.append(datetime.now().strftime('%Y.%m.%d-%H.%M.%S'))
    cfg.evaluation_name = '-'.join(_parts)
    print(cfg)
    needs_patch = getattr(cfg, 'patch_grounding', False) or getattr(cfg, 'dek_dual_gate', False)
    ckpt = cfg.editor_ckpt_path
    editor = load_vllm_editor(
        cfg.editor_name, cfg.edit_model_name, cfg.device, None,
        None if needs_patch else ckpt,
        False,
    )
    if needs_patch:
        editor.enable_patch_grounding(encoder='dinov2', expert_gen=True)
    if getattr(cfg, 'dek_dual_gate', False):
        editor.enable_dek(dual_gate=True, encoder='dinov2')
    if needs_patch and ckpt:
        editor.load_ckpt(ckpt, True, False)
    # AR-LiveEdit: set editor flags so edit_one_piece uses chunk-wise path when --ar_mode
    if hasattr(editor, 'ar_mode'):
        editor.ar_mode = getattr(cfg, 'ar_mode', False)
        editor.chunk_size = getattr(cfg, 'chunk_size', 16)
        editor.max_chunks = getattr(cfg, 'max_chunks', None)
    # load data
    if cfg.data_name == 'EVQA':
        from dataset.vllm import EVQA
        data_path = os.path.join(ROOT_PATH, 'data/easy-edit-mm/vqa/vqa_eval.json')
        img_root_dir = os.path.join(ROOT_PATH, 'data/easy-edit-mm/images')
        eval_data = EVQA(data_path, img_root_dir, cfg.data_sample_n)
    elif cfg.data_name == 'EIC':
        from dataset.vllm import EIC
        data_path = os.path.join(ROOT_PATH, 'data/easy-edit-mm/caption/caption_eval_edit.json')
        img_root_dir = os.path.join(ROOT_PATH, 'data/easy-edit-mm/images')
        eval_data = EIC(data_path, img_root_dir, cfg.data_sample_n)
    elif cfg.data_name == 'VLKEB':
        from dataset.vllm import VLKEB
        data_path = getattr(cfg, 'vlkeb_eval_json', None) or os.path.join(ROOT_PATH, 'data/VLKEB/eval.json')
        if data_path and not os.path.isabs(data_path):
            data_path = os.path.join(ROOT_PATH, data_path)
        img_root_dir = os.path.join(ROOT_PATH, 'data/VLKEB/VLKEB_images/mmkb_images')
        eval_data = VLKEB(data_path, img_root_dir, cfg.data_sample_n)
    # evaluate (use fixed seed when provided for reproducible baseline vs AR comparison)
    use_random = getattr(cfg, 'eval_seed', None) is not None
    eval_seed = getattr(cfg, 'eval_seed', None)
    ev = VLLMEditorEvaluation(editor, eval_data, cfg.evaluation_name, 'eval_results', ar_chunk_size=getattr(cfg, 'chunk_size', 16))
    t0 = time.time()
    free_running = getattr(cfg, 'free_running', False)
    if free_running:
        ev.evaluate_sequential_edit_freegen(
            cfg.sequential_edit_n, use_random, eval_seed,
            gen_eval_n=getattr(cfg, 'gen_eval_n', 200),
            max_new_tokens=getattr(cfg, 'gen_max_new_tokens', 128))
    else:
        ev.evaluate_sequential_edit(cfg.sequential_edit_n, use_random, eval_seed)
    elapsed = time.time() - t0
    if free_running:
        mean_results_fname = ('seed_%s_freegen_mean_results.json' % eval_seed) if use_random else 'freegen_mean_results.json'
    else:
        mean_results_fname = ('seed_%s_mean_results.json' % eval_seed) if use_random else 'mean_results.json'
    mean_results_path = os.path.join(ev.result_dir, 'sequential_edit_%s' % cfg.sequential_edit_n, mean_results_fname)
    if os.path.exists(mean_results_path):
        with open(mean_results_path, 'r') as f:
            data = json.load(f)
        data['runtime_seconds'] = round(elapsed, 2)
        data['runtime_minutes'] = round(elapsed / 60, 2)
        with open(mean_results_path, 'w') as f:
            json.dump(data, f, indent=4)
    print('[Timer] Total elapsed: %.2f s (%.2f min)' % (elapsed, elapsed / 60))

